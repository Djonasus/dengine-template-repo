import SceneComponent from './components/SceneComponent';
import { SceneManager } from './DEngine/SceneManager';
import { MainScene } from './examples/MainScene';

function App() {

 SceneManager.getInstance().registerScene(new MainScene("main"));

  return (
    <>
      <SceneComponent sceneName="main" antialias />
    </>
  )
}

export default App
