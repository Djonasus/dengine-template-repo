import { FC, useEffect, useRef } from "react";
import { Engine, Scene } from "@babylonjs/core";
import { Inspector } from '@babylonjs/inspector';
import { SceneManager } from "../DEngine/SceneManager";

interface SceneComponentProps {
    sceneName: string;
    antialias?: boolean;
    engineOptions?: EngineOptions;
    adaptToDeviceRatio?: boolean;
    sceneOptions?: SceneOptions;
}

interface EngineOptions {
    preserveDrawingBuffer?: boolean;
    stencil?: boolean;
}

interface SceneOptions {
    useGeometryUniqueIdsMap?: boolean;
    useMaterialMeshMap?: boolean;
    useClonedMeshMap?: boolean;
}

const SceneComponent: FC<SceneComponentProps> = ({
    sceneName,
    antialias = true,
    engineOptions = {},
    adaptToDeviceRatio = true,
    sceneOptions = {}
}) => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        // Создаем движок и сцену
        const engine = new Engine(
            canvas,
            antialias,
            engineOptions,
            adaptToDeviceRatio
        );
        const scene = new Scene(engine, sceneOptions);

        // Загружаем сцену через SceneManager
        const loadScene = () => {
            try {
                SceneManager.getInstance().loadScene(sceneName, scene);
            } catch (error) {
                console.error("Ошибка загрузки сцены:", error);
            }
        };

        if (scene.isReady()) {
            loadScene();
        } else {
            scene.onReadyObservable.addOnce(loadScene);
        }

        // Основной цикл рендеринга
        engine.runRenderLoop(() => {
            const deltaTime = engine.getDeltaTime();
            SceneManager.getInstance().update(deltaTime);
            scene.render();
        });

        // Обработчик изменения размера окна
        const handleResize = () => {
            engine.resize();
        };

        // Обработчик для показа/скрытия инспектора (клавиша W)
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.code === "KeyW") {
                if (Inspector.IsVisible) {
                    Inspector.Hide();
                } else {
                    Inspector.Show(scene, {
                        overlay: true
                    });
                }
            }
        };

        // Добавляем слушатели событий
        window.addEventListener("resize", handleResize);
        window.addEventListener("keydown", handleKeyDown);

        // Очистка при размонтировании компонента
        return () => {
            engine.stopRenderLoop();
            scene.dispose();
            engine.dispose();
            
            window.removeEventListener("resize", handleResize);
            window.removeEventListener("keydown", handleKeyDown);
        };
    }, [sceneName, antialias, engineOptions, adaptToDeviceRatio, sceneOptions]);

    return (
        <canvas
            ref={canvasRef}
            style={{
                width: '100%',
                height: '100%',
                outline: 'none',
                touchAction: 'none'
            }}
        />
    );
};

export default SceneComponent;